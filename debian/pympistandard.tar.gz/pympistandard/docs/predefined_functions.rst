====================
PREDEFINED FUNCTIONS
====================
